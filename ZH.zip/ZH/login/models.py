from __future__ import unicode_literals

from django.db import models

class User(models.Model):
    created = models.DateField(auto_now_add=True)
    username = models.CharField(max_length=20, primary_key=True)
    password = models.CharField(max_length=20)
    sex = models.CharField(max_length=20, default='women')

    class Meta:
        ordering = ('username',)
