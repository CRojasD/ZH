from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns
from round import views

urlpatterns = [
    url(r'^round/$', views.user_list),
    url(r'^round/(?P<user>[a-zA-Z]+)$', views.user_detail),
]

urlpatterns = format_suffix_patterns(urlpatterns)
