from __future__ import unicode_literals

from django.db import models

class Players(models.Model):
    user = models.CharField(max_length=20, primary_key=True)
    isZombie = models.BooleanField()
    isHuman = models.BooleanField()
    isInfected = models.BooleanField()
    hasCure = models.BooleanField()
    puntuation = models.IntegerField(default=0)
    started = models.DateTimeField(auto_now=True)
    sex = models.CharField(max_length=20, default="women")
    
    class Meta():
        ordering = ('user',)
