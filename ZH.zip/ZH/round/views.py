from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from models import Players
from serializer import PlayersSerializer

@api_view (['GET', 'POST'])
def user_list(request, format=None):
    """
    List all players, or create a new player.
    """
    if request.method == 'GET':
        players = Players.objects.all()
        serializer = PlayersSerializer(players, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = PlayersSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view (['GET', 'PUT', 'DELETE'])
def user_detail(request, user, format=None):
    """
    Retrieve, update or delete a user instance.
    """
    try:
        player = Players.objects.get(user=user)
    except Players.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = UserSerializer(player)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = PlayersSerializer(player, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        player.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
