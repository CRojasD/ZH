from rest_framework import serializers
from models import Players

class PlayersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Players
        fields = ('user', 'isZombie', 'isHuman', 'isInfected', 'hasCure', 'sex', 'puntuation', 'started')

    def create(self, validated_data):
        """
        Create and return a new `Players` instance, given the validated data.
        """
        return Players.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Players` instance, given the validated data.
        """
        instance.isZombie = validated_data.get('isZombie', instance.isZombie)
        instance.isHuman = validated_data.get('isHuman', instance.isHuman)
        instance.isInfected = validated_data.get('isInfected', instance.isInfected)
        instance.hasCure = validated_data.get('hasCure', instance.hasCure)
        instance.puntuation = validated_data.get('puntuation', instance.puntuation)
        instance.save()
        return instance
