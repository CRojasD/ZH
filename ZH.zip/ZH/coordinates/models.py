from __future__ import unicode_literals
from django.db import models

class Location(models.Model):
    user = models.CharField(max_length=10, primary_key=True)
    latitude = models.DecimalField(decimal_places=20, max_digits=30)
    longitude = models.DecimalField(decimal_places=20, max_digits=30)

    class Meta:
        ordering = ('user',)
