from rest_framework import serializers
from models import waitingUsers

class waitingUsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = waitingUsers
        fields = ('user', 'isZombie')

    def create(self, validated_data):
        """
        Create and return a new 'waitingUsers' instance, given de validated data
        """
        return waitingUsers.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Create and return a new 'waitingUsers' instance, given the validated_data
        """
        instance.isZombie = validated_data.get('isZombie', instance.isZombie)
        instance.save()
        return instance
