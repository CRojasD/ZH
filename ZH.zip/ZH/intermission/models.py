from __future__ import unicode_literals
from django.db import models

class waitingUsers(models.Model):
    user = models.CharField(max_length=20, primary_key=True)
    isZombie = models.BooleanField()
