from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from models import waitingUsers
from serializer import waitingUsersSerializer

@api_view(['GET', 'POST'])
def waitingUsers_list(request, format=None):
    """
    List all the waitingUsers, or create a new one
    """
    if request.method == 'GET':
        waiting = waitingUsers.objects.all()
        serializer = waitingUsersSerializer(waiting, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = waitingUsersSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT', 'DELETE'])
def waitingUsers_detail(request, user, format=None):
    """
    Retrive, update or delete a user instance
    """
    try:
        waiting = waitingUsers.objects.get(user=user)
    except waitingUsers.DoesNotExist:
        return Response(status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = waitingUsersSerializer(waiting)
        return Response(serializer.data)

    elif request.method == 'PUT':
        serializer = waitingUsersSerializer(waiting, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        waiting.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
