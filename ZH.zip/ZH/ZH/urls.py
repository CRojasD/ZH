from django.conf.urls import url, include
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^', include('login.urls')),
    url(r'^', include('coordinates.urls')),
    url(r'^', include('intermission.urls')),
    url(r'^', include('round.urls')),
]
